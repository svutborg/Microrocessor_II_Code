/* 
 * File:   i2c.h
 * Author: ihn
 *
 * Created on 15. marts 2017, 00:01
 */

#ifndef I2C_H
#define	I2C_H

class test 
   {
   public:
      test();
      voiod hej();
   };

#endif	/* I2C_H */

